#ifndef __IIC_H__
#define __IIC_H__

#include "main.h"

//PC11-->SCL         PC12-->SDA
#define I2C_SDA_HIGH   HAL_GPIO_WritePin(GPIOC,GPIO_PIN_12,GPIO_PIN_SET)              //SDA�ߵ�ƽ
#define I2C_SDA_LOW    HAL_GPIO_WritePin(GPIOC,GPIO_PIN_12,GPIO_PIN_RESET)            //SDA�͵�ƽ
#define I2C_SCL_HIGH   HAL_GPIO_WritePin(GPIOC,GPIO_PIN_11,GPIO_PIN_SET)
#define I2C_SCL_LOW    HAL_GPIO_WritePin(GPIOC,GPIO_PIN_11,GPIO_PIN_RESET)

#define I2C_SDA        HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_12)                            //��ȡSDA��ƽ
#define I2C_SCL        HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_11)

void I2C_Start(void);
void I2C_Stop(void);
void I2C_Send(uint8_t data);
uint8_t I2C_Read(void);
char  I2C_Wit_Ack(void);
void SDA_OUT(void);
void I2C_Ack(void);
void I2C_No_ack(void);
void SDA_OUT(void);
void SDA_IN(void);
void delay_us(uint32_t udelay);
int32_t IICwriteBytes(uint8_t dev, uint8_t reg, uint8_t* data, uint32_t length);
int32_t IICreadBytes(uint8_t dev, uint8_t reg, uint8_t *data, uint32_t length);

#endif
